﻿namespace Domain
{
    public class User
    {
        public string FIO;
        public string Phone_Number;

        public User(string fio, string phone_number)
        {
            FIO = fio;
            Phone_Number = phone_number;
        }
    }
}